# NoorAI

A simple Next.js Islamic AI website starter.