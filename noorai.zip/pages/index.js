export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Noor AI</h1>
      <p>Welcome to Noor AI. Your Islamic AI Companion.</p>
    </div>
  );
}